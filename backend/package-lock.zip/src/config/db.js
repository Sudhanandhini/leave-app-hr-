const mysql2 = require('mysql2/promise');

const pool = mysql2.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'leave_management',
  waitForConnections: true,
  connectionLimit: 10,
  dateStrings: true, // Return DATE/DATETIME as 'YYYY-MM-DD' strings — avoids IST timezone shift via toISOString()
});

module.exports = pool;
